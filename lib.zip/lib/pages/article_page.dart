import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/api.dart';

class ArticlePage extends StatefulWidget {
  const ArticlePage({super.key});

  @override
  State<ArticlePage> createState() => _ArticlePageState();
}

class _ArticlePageState extends State<ArticlePage> {
  List items = [];
  bool loading = true;

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final res = await Api.dio.get("/articles/list.php");
      final parsed = res.data is String ? jsonDecode(res.data) : res.data;
      items = (parsed["success"] == true) ? parsed["data"] : [];
    } catch (_) {
      items = [];
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());

    return ListView.builder(
      itemCount: items.length,
      itemBuilder: (_, i) {
        final m = items[i] as Map<String, dynamic>;
        return ListTile(
          title: Text(m["title"].toString()),
          subtitle: Text(m["content"].toString(), maxLines: 2, overflow: TextOverflow.ellipsis),
          trailing: Text(m["created_at"].toString()),
          onTap: () {
            // ✅ message dialog
            showDialog(
              context: context,
              builder: (_) => AlertDialog(
                title: Text(m["title"].toString()),
                content: Text(m["content"].toString()),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(context), child: const Text("Tutup"))
                ],
              ),
            );
          },
        );
      },
    );
  }
}
