import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/api.dart';
import '../widgets/shoe_card.dart';

class CatalogPage extends StatefulWidget {
  const CatalogPage({super.key});

  @override
  State<CatalogPage> createState() => _CatalogPageState();
}

class _CatalogPageState extends State<CatalogPage> {
  List items = [];
  bool loading = true;

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final res = await Api.dio.get("/shoes/list.php");
      final parsed = res.data is String ? jsonDecode(res.data) : res.data;
      if (parsed["success"] == true) {
        items = parsed["data"];
      } else {
        items = [];
      }
    } catch (_) {
      items = [];
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());

    return RefreshIndicator(
      onRefresh: load,
      child: items.isEmpty
          ? ListView(
        children: [
          SizedBox(height: 120),
          Center(child: Text("Data sepatu kosong")),
        ],
      )
          : ListView.builder(
        itemCount: items.length,
        itemBuilder: (_, i) {
          final m = items[i] as Map<String, dynamic>;
          return ShoeCard(
            name: m["name"].toString(),
            brand: m["brand"].toString(),
            price: m["price"].toString(),
            imageUrl: m["image_url"].toString(), // ✅ network image
            onFav: () {
              // ✅ snackbar
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("${m["name"]} ditambahkan ke favorit")),
              );
            },
          );
        },
      ),
    );
  }
}
